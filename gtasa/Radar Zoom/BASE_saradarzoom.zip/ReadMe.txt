San Andreas Radar Zoom 1.0
by Silent
based on Vice City Radar Zoom by spaceeinstein


DESCRIPTION

	Simpleish thing. If you played GTA IV, you may remember that pressing a certain key would zoom the radar out
	fully and show your current area/car name on screen. This mod brings that feature to San Andreas.


INSTALLATION

	This mod is compatible with the CLEO 3/4 Libraries found here:
	http://cleo.sannybuilder.com/

	Put 'CLEO' folder (with all its content) in your game directory.


USAGE

	Press T to zoom the radar out and to display the area and vehicle names. The key can be held down
	to keep the effect turned on.


KNOWN BUGS

	As the mod modifies several hardcoded routines, it might crash on some EXE versions.
	These EXE versions are tested and supported fully:
	* 1.0 (all versions)
	* 1.01 (all versions)

	Contact me if you have any problems with it.


CREDITS & LICENSE

	Thanks to spaceeinstein for leaving a source code of his Vice City Radar Zoom mod and for allowing to convert
	it to San Andreas.
	As the following modification is open source, it's under the Silent's License.
	It means that the source code is for learning purposes, as all source code is. You may only use it for your own projects
	but NOT to recreate or build on the original work.


CONTACT

	zdanio95@gmail.com - MSN

Follow my Twitter account to be up to all my mods updates!
http://twitter.com/__silent_