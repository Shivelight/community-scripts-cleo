  __  __ _      __  __           _     
 |  \/  (_)    |  \/  |         | | 2022
 | \  / |___  _| \  / | ___   __| |___ 
 | |\/| | \ \/ / |\/| |/ _ \ / _` / __|
 | |  | | |>  <| |  | | (_) | (_| \__ \
 |_|  |_|_/_/\_\_|  |_|\___/ \__,_|___/
                                       

=======   MixMods.com.br   ======= - Best visualization with monospaced fonts, like "Consolas".


------- Instructions:

Extract the folder "Enterable Hidden Interiors" to your Modloader folder.

Unlike the original version of the mod, this one uses a CLEO script so you don't need to modify .ipl files (thus compatible with map mods like Proper Fixes).

The mod also modifies several other .dff, .txd and .col files, you may need to increase the priority of this mod in modloader (especially if you use Tuning Mod):
http://www.mixmods.com.br/2015/07/tutorial-dicas-tudo-sobre-mod-loader.html#priority

The mod comes with "SimpleLimitAdjuster_Enex.asi". It is not required if you increase the "Entry Exists" limit of fastman92 limit adjuster.

-- Essentials Pack download: https://www.mixmods.com.br/2019/06/sa-essentials-pack/
-- REQUIRES CLEO+ (already included in Essentials Pack).



---- Commands ----
Note: Some commands change depending on the layout of your keyboard, this is normal and can happen in any mod.

ABNT or US keyboard:
Press     \-     to close the aircraft carrier hold
Press     \=     to open aircraft carrier hold

US keyboard:
Press     [-     to lower small aircraft carrier platform
Press     [=     to raise small aircraft carrier platform
Press     ]-     to lower the big aircraft carrier platform
Press     ]=     to lift large aircraft carrier platform

ABNT Keyboard:
Press     �-     to lower small aircraft carrier platform
Press     �=     to lift small aircraft carrier platform
Press     [-     to lower large aircraft carrier platform
Press     [=     to raise large aircraft carrier platform

For example: Hold \ and press - will close the hold of the aircraft carrier.
 


Version: v4.3
Unofficial updates by Junior_Djjr: SimpleLimitAdjuster_Enex.asi + mipmapped txd + Tuning Mod adaptation + Escalator Physics Fix + World Of Coq sky fix + More Radar Icons adaptation + .cs script instead of replacing .ipl
(SimpleLimitAdjuster_Enex.asi is the same as EHI.asi but with a higher limit, and the same as increasing the "Entry Exists" limit in f92la)
--------------------

Author: artginPL
Fixes, improvements, ModLoader installation and SimpleLimitAdjuster_Enex.asi: Junior_Djjr


====   MixMods.com.br                ====
====   fb.com/FamiliaMixMods         ====
====   youtube.com/JuniorDjjrMixMods ====

