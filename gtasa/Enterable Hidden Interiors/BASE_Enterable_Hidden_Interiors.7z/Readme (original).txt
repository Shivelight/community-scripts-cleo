_________________________________________

ENTERABLE HIDDEN INTERIORS V4.3

_________________________________________
_________________________________________
AUTHOR
_________________________________________
	artginPL


_________________________________________
UPDATE
_________________________________________
	2020-12-02   (YYYY-MM-DD)


_________________________________________
ABOUT
_________________________________________
	This mod allows you to enter the buildings which are visible only in cut-scenes, some of the missions in GTA San Andreas or not used at all in the game.
	Most of the interiors has made new collision files. GTA SA has 376 entrance exit (enex) markers, and this modification adds another 124.
	
	LIST OF THE ENTERABLE BUILDINGS:

	1. LOS SANTOS:
	- Sweet's House (Ganton),
	- Ryder's House (Ganton),
	- OG Loc's House (Ganton),
	- B Dup's Apartment (Ganton),
	- B Dup's Crack Palace (Glen Park),
	- Blastin' Fools Records (Market),
	- Crack Den - Ballas Apartment (Idlewood),
	- Vagos Gang House (East Los Santos),
	- Two-Floors Ammunation (Downtown),
	- Arena from 'New Model Army' missions (entry in front of Film Studio in Vinewood),
	- Los Santos International Airport,
	- Sayonara Hotel&Restaurant (Verdant Bluffs),
	- The Bog Standard Hotel (Temple),
	- All floors of the Los Santos Office [glazed building] - (Downtown).

	2. SAN FIERRO:
	- Woozie's Apartment (Chinatown),
	- San Fierro Police Department (Downtown),
	- Preasure Domes (Battery Point),
	- Supa Save (Juniper Hill),
	- San Fierro Easter Bay International Airport,
	- Doherty Garage with fixed camera view - CONTROLS IS BELOW,
	- Adds the possibility to open and close of the hold, and the possibility of lifting and lowering of the two platforms on the Aircraft Carrier (Easter Basin) - CONTROLS IS BELOW.
	_________________________________________
	|                                       |
	|       CONTROLS:                       |
	|                                       |
	|   -  garage close                     |
	|   =  garage open                      |
	|   \-  close of the hold               |
	|   \=  open of the hold                |
	|   [-  lowering of the small platform  |
	|   [=  lifting of the small platform   |
	|   ]-  lowering of the big platform    |
	|   ]=  lifting of the big platform     |
	|_______________________________________|

	3. LAS VENTURAS:
	- City Planning Department (Come-A-Lot),
	- New Room in Bike School (Blackfield),
	- Sindacco Abattoir (Whietwood Estates),
	- Rosenberg's Room in Caligula's Palace,
	- Woozie's Room in The Four Dragons Cassino,
	- Janitor Room in The Four Dragons Cassino,
	- Las Venturas Airport,
	- Adds entry to eight casinos (Come-A-Lot, The Emerald Isle, The High Roller, The Pink Swan, Starfish Casino, The Visage, Old Venturas Strip x2),
	- Las Venturas Bandits Stadium (Redsands West),
	- Plastic Factory (Whietwood Estates),
	- Basements in Caligula's Palace.

	4. OTHER:
	- Rusty Brown's Ring Donuts (Market, Palisades and Fort Carson),
	- U Get Inn Motel (Angel Pine and Fort Carson),
	- Welcome Pump (Dillimore),
	- Bank (Palomino Creek),
	- Cesar's Hideout (Angel Pine),
	- Police Stations (Angel Pine and Fort Carson),
	- Interior of the Shamal aircraft (entry in every Airports),
	- Area around of the Liberty City Saint Marks (entry in Shamal aircraft),
	- Interior of the Liberty City Marco Bistro,
	- All Hauses of CJ's Girlfriends,
	- Brothel1 (Valle Ocultado),
	- Brothel2 (entry in Strip Clubs),
	- Nude & XXX Shop (Los Santos x2, Las Venturas x1),
	- Sex Shop XXX (Los Santos x1, Las Venturas x4),
	- Sodom Sex Toys (Los Santos x2),
	- Adds unused save house to Mike Toreno's Ranch (Tierra Robada),
	- Main entry to underground of Area 69,
	- Manhole with jetpack in Area 69,
	- Gas Station (Dillimore),
	- All gas stations buildings with 24/7 interiors, including three interiors unused by game (all San Andreas),
	- All bars and restaurants from Dating Missions (all San Andreas),
	- Many stores with 24/7 interiors, including three interiors unused by game (all San Andreas),
	- Makes that the vent in Area 69 is not blocked,
	- Gates in fence of Area 69 are movable.

	In some interiors (SWEETS, RYDERS, STUDIO, BDUPS1, WUZIBET, AIRPOR2, BROTHL2) are hidden markers, which are remnants of the original game files.


_________________________________________
SUPPORTED GAME VERSIONS
_________________________________________
	GTA San Andreas 1.0 US HOODLUM (14 383 616 bytes)


_________________________________________
INSTALLATION
_________________________________________
You need a CLEAN copy of GTA San Andreas for installation this mod.
	
STEP 1.
	Drag all files from the 'GTA San Andreas' folder to the root game folder.
	Allow replacement of any required files.

STEP 2.
	Run the 'INSTALL - EHI.bat' file located in the root game folder.
	Wait patiently for the console window to disappear (about 30 seconds).
	Do not disable this window yourself!

STEP 3.
	Delete the following files from the root game folder:
	- 'fastman92ImgConsole32.exe'
	- 'INSTALL - EHI.bat'
	- 'EHI-IMG_CHANGES.txt'
	- 'EHI_IMG_FILES' folder

Make sure you have 'gta_sa.exe' version 1.0 US HOODLUM (14 383 616 bytes).
This mod requires an installed CLEO library (v4), and ASI Loader.


_________________________________________
CREDITS / SPECIAL THANKS
_________________________________________
	Silent   (made of the .asi file)


_________________________________________
CONTACT WITH AUTHOR
_________________________________________
	E-mail:	artginpl@gmail.com
	Blog:	https://artginpl.blogspot.com

