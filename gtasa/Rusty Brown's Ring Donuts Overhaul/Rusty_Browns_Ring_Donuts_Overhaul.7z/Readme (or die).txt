  __  __ _      __  __           _     
 |  \/  (_)    |  \/  |         | | 2020
 | \  / |___  _| \  / | ___   __| |___ 
 | |\/| | \ \/ / |\/| |/ _ \ / _` / __|
 | |  | | |>  <| |  | | (_) | (_| \__ \
 |_|  |_|_/_/\_\_|  |_|\___/ \__,_|___/
                                       

=======   MixMods.com.br   ======= - Best visualization with monospaced fonts, like "Consolas".


------- Instructions:

Extract the folder "Rusty Brown's Ring Donuts Overhaul" to your Modloader folder.

-- Download the latest version of Modloader: MixMods.com.br/2015/01/SA-Modloader.html
 

 The icons on the radar map can be saved in your game after saving the game.

 If the entry markers doesn't appear (and you're sure the mod is working),
�"EnexEntries" from MixSets or "SimpleLimitAdjuster_Enex.asi" can solve.

�The mod has an .ini file in case you want to configure something,
�it can be useful to change the icon ID when adding an icon without replacing it with fastman92 limit adjuster.
 One tip is to change the icon ID to "26" and change the "radar_MCSTRAP" image from "hud.txd" with Magic.TXD for some donut icon.


--------------------

Author original: ATP
Fixes and improvements: AlphaBit


====   MixMods.com.br                ====
====   fb.com/FamiliaMixMods         ====
====   youtube.com/JuniorDjjrMixMods ====

